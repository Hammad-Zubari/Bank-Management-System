
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HAMMAD
 */
public class Conec {
    public static Connection getCon()
     {
         try{
            String url="jdbc:mysql://localhost:3306/bank?zeroDateTimeBehavior=CONVERT_TO_NULL";
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, "root", "Hammad123");
            return con;
            
         }
         catch( ClassNotFoundException | SQLException e)
         {
             System.out.println(e);
             
             return null;
         }
         
     }
     
  
}
