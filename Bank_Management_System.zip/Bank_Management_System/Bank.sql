create database Bank;

show databases;

select * from Account;
use bank;
show tables;

create table B_Account ( 
Acc int primary key,
 A_name varchar(20),
 DOB  varchar(20) ,
 Pin int, 
 Acc_Type varchar(20),
 Nationality varchar(20),
 Gender varchar(20), 
 Mob int, 
 Address  varchar(20),
Balance int
 );
 
 select * from Balance;
 select * from B_Account;
drop table B_Account;
CREATE TABLE Balance (
A_name  varchar(20),
Acc int, 
Balance int
 );
